/* {{NO_DEPENDENCIES}} */
/* Microsoft Developer Studio generated include file. */
/* Used by psqlodbc.rc */

#define IDS_BADDSN                      1
#define IDS_MSGTITLE                    2
#define DLG_OPTIONS_DRV                 102
#define DLG_OPTIONS_DS                  103
#define IDC_DSNAME                      400
#define IDC_DSNAMETEXT                  401
#define IDC_DESC                        404
#define IDC_SERVER                      407
#define IDC_DATABASE                    408
#define DLG_CONFIG                      1001
#define IDC_PORT                        1002
#define IDC_USER                        1006
#define IDC_PASSWORD                    1009
#define DS_READONLY                     1011
#define DS_SHOWOIDCOLUMN                1012
#define DS_FAKEOIDINDEX                 1013
#define DRV_COMMLOG                     1014
#define DS_PG62                         1016
#define IDC_DATASOURCE                  1018
#define DRV_OPTIMIZER                   1019
#define DS_CONNSETTINGS                 1020
#define IDC_DRIVER                      1021
#define DRV_CONNSETTINGS                1031
#define DRV_UNIQUEINDEX                 1032
#define DRV_UNKNOWN_MAX                 1035
#define DRV_UNKNOWN_DONTKNOW            1036
#define DRV_READONLY                    1037
#define IDC_DESCTEXT                    1039
#define DRV_MSG_LABEL                   1040
#define DRV_UNKNOWN_LONGEST             1041
#define DRV_TEXT_LONGVARCHAR            1043
#define DRV_UNKNOWNS_LONGVARCHAR        1044
#define DRV_CACHE_SIZE                  1045
#define DRV_VARCHAR_SIZE                1046
#define DRV_LONGVARCHAR_SIZE            1047
#define IDDEFAULTS                      1048
#define DRV_USEDECLAREFETCH             1049
#define DRV_BOOLS_CHAR                  1050
#define DS_SHOWSYSTEMTABLES             1051
#define DRV_EXTRASYSTABLEPREFIXES       1051
#define DS_ROWVERSIONING                1052
#define DRV_PARSE                       1052
#define DRV_CANCELASFREESTMT            1053
#define IDC_OPTIONS                     1054
#define DRV_KSQO                        1055
#define DS_PG64                         1057
#define DS_PG63                         1058

/* Next default values for new objects */

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
